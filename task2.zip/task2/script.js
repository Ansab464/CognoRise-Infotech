document.addEventListener('DOMContentLoaded', function () {
    const taskInput = document.getElementById('task-input');
    const addTaskBtn = document.getElementById('add-task-btn');
    const taskList = document.getElementById('task-list');
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
  
    const displayTasks = () => {
      taskList.innerHTML = '';
      tasks.forEach((task, index) => {
        const li = document.createElement('li');
        li.classList.add('task-item');
        li.innerHTML = `
          <span>${task}</span>
          <div>
            <button class="edit">Edit</button>
            <button class="delete">Delete</button>
          </div>
        `;
        taskList.appendChild(li);

        li.querySelector('.edit').addEventListener('click', () => {
          const newTask = prompt('Edit your task', task);
          if (newTask) {
            tasks[index] = newTask;
            updateTasks();
          }
        });
  
        li.querySelector('.delete').addEventListener('click', () => {
          tasks.splice(index, 1);
          updateTasks();
        });
      });
    };
  
    addTaskBtn.addEventListener('click', () => {
      const task = taskInput.value.trim();
      if (task) {
        tasks.push(task);
        updateTasks();
        taskInput.value = '';
      }
    });
  
    const updateTasks = () => {
      localStorage.setItem('tasks', JSON.stringify(tasks));
      displayTasks();
    };
    displayTasks();
  });
  