let display = document.getElementById("display");
let currentInput = "";
let result = "";
function updateDisplay() {
    display.textContent = currentInput || result || "0";
}
document.querySelectorAll(".btn").forEach(button => {
    const value = button.value;

    button.addEventListener("click", () => {
        if (button.id === "equals") {
            try {
                result = eval(currentInput);
                currentInput = "";
            } catch (error) {
                result = "Error"; 
                currentInput = "";
            }
        } else if (button.id === "clear") {
            currentInput = "";
            result = "";
        } else if (button.id === "backspace") {
            currentInput = currentInput.slice(0, -1); 
        } else {
            currentInput += value; 
        }
        
        updateDisplay();
    });
});

updateDisplay();
