function scrollToSection(sectionId) {
    document.getElementById(sectionId).scrollIntoView({
        behavior: 'smooth'
    });
}

const skills = document.querySelectorAll('.skill');

skills.forEach(skill => {
    skill.addEventListener('mouseover', () => {
        skill.style.backgroundColor = '#007bff';
        skill.style.color = '#fff';
    });

    skill.addEventListener('mouseout', () => {
        skill.style.backgroundColor = '#f0f0f0';
        skill.style.color = '#333';
    });
});
